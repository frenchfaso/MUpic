//! Export the exact native Guest PAL preset to browser WGSL ahead of time.
//! No GLSL/SPIR-V compiler, shader source parser, or native library is shipped.
use librashader_pack::ShaderPresetPack;
use librashader_presets::{ShaderFeatures, ShaderPreset, Scaling};
use librashader_reflect::back::{CompileShader, targets::WGSL};
use librashader_reflect::front::SpirvCompilation;
use librashader_reflect::reflect::{ReflectShader, naga::{Naga, NagaLoweringOptions}, presets::CompilePresetTarget};
use librashader_reflect::reflect::semantics::{MemberOffset, Semantic, TextureSemantics};
use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::{collections::BTreeMap, error::Error, fs, path::{Path, PathBuf}};
type Result<T> = std::result::Result<T, Box<dyn Error + Send + Sync>>;

fn sha(bytes: &[u8]) -> String { format!("{:x}", Sha256::digest(bytes)) }
fn save(out: &Path, name: &str, bytes: &[u8]) -> Result<Value> {
    fs::write(out.join(name), bytes)?;
    Ok(json!({"file":name,"sha256":sha(bytes),"bytes":bytes.len()}))
}
fn offset(o: MemberOffset) -> Value { json!({"ubo":o.ubo,"push":o.push}) }
fn texture(t: Semantic<TextureSemantics>) -> Value { json!({"semantic":format!("{:?}",t.semantics),"index":t.index}) }
fn scaling(s: &Scaling) -> Value { json!({"type":format!("{:?}",s.scale_type),"factor":f32::from(s.factor)}) }
// Resolve emitted identifiers by binding: the WGSL writer can disambiguate IR
// names (OriginalHistory0 -> OriginalHistory0_, Pass1 -> Pass1_).
fn wgsl_texture_name(source: &str, binding:u32) -> Result<String> {
    let marker=format!("@group(0) @binding({binding})");
    let at=source.find(&marker).ok_or_else(||format!("Missing WGSL texture binding {binding}"))?+marker.len();
    let declaration=source[at..].trim_start().strip_prefix("var ")
        .ok_or_else(||format!("WGSL binding {binding} is not a texture declaration"))?;
    let (name,kind)=declaration.split_once(':').ok_or("Invalid WGSL texture declaration")?;
    if !kind.trim_start().starts_with("texture_2d<f32>") { return Err(format!("Unexpected WGSL texture type at {binding}").into()); }
    Ok(name.trim().to_string())
}
// WebGPU has no clamp-to-transparent-border sampler. Keep the exact native
// normalized sampling footprint, including its half-texel linear border blend.
// This is an API adaptation; the original PAL/CRT shader calculations are intact.
fn lower_border(source: &str, samplers: &BTreeMap<String,bool>, border_binding:u32) -> Result<String> {
    let mut output=String::with_capacity(source.len()+2000);
    let mut at=0;
    while let Some(relative)=source[at..].find("textureSample") {
        let start=at+relative;
        output.push_str(&source[at..start]);
        let level=source[start..].starts_with("textureSampleLevel(");
        let basic=source[start..].starts_with("textureSample(");
        if !level && !basic { return Err("Unsupported native texture sampling operation".into()); }
        let open=start+if level {19}else{14};
        let comma=source[open..].find(',').ok_or("Malformed native texture sampling operation")?;
        let name=source[open..open+comma].trim();
        if let Some(linear)=samplers.get(name) {
            output.push_str(match (level,*linear) {(false,false)=>"ue2_border_nearest(",(false,true)=>"ue2_border_linear(",(true,true)=>"ue2_border_level_linear(",(true,false)=>"ue2_border_level_nearest("});
        } else { return Err(format!("Unadapted native sampler {name}").into()); }
        at=open;
    }
    output.push_str(&source[at..]);
    output.push_str(&format!("\n@group(0) @binding({border_binding}) var ue2_border_coverage:texture_2d<f32>;\n@group(1) @binding({border_binding}) var ue2_border_coverage_sampler:sampler;\n"));
    output.push_str(r#"
fn ue2_border_weight(dim:vec2<f32>, uv:vec2<f32>) -> f32 {
    let p=uv*dim;
    let left=clamp(p+vec2<f32>(1.0),vec2<f32>(0.5),vec2<f32>(1.5));
    let right=clamp(p-dim+vec2<f32>(2.0),vec2<f32>(1.5),vec2<f32>(2.5));
    let coordinate=select(left,right,p>dim*vec2<f32>(0.5));
    // A black 3x3 texture with one white centre texel delegates the fractional
    // border weight to the GPU's own bilinear unit. Preserve each edge's
    // orientation: reflecting right/bottom changes its quantized phase.
    return textureSampleLevel(ue2_border_coverage,ue2_border_coverage_sampler,coordinate/3.0,0.0).r;
}
fn ue2_border_linear(t: texture_2d<f32>, s: sampler, uv: vec2<f32>) -> vec4<f32> {
    let dim=vec2<f32>(textureDimensions(t,0));
    return textureSample(t,s,uv)*ue2_border_weight(dim,uv);
}
fn ue2_border_nearest(t: texture_2d<f32>, s: sampler, uv: vec2<f32>) -> vec4<f32> {
    return textureSample(t,s,uv)*select(0.0,1.0,all(uv>=vec2<f32>(0.0)) && all(uv<vec2<f32>(1.0)));
}
fn ue2_border_level_linear(t: texture_2d<f32>, s: sampler, uv: vec2<f32>, lod: f32) -> vec4<f32> {
    let level=clamp(lod,0.0,f32(textureNumLevels(t)-1u));
    let low=u32(floor(level)); let high=min(low+1u,textureNumLevels(t)-1u);
    let dl=vec2<f32>(textureDimensions(t,low)); let dh=vec2<f32>(textureDimensions(t,high));
    return mix(textureSampleLevel(t,s,uv,f32(low))*ue2_border_weight(dl,uv),textureSampleLevel(t,s,uv,f32(high))*ue2_border_weight(dh,uv),fract(level));
}
fn ue2_border_level_nearest(t: texture_2d<f32>, s: sampler, uv: vec2<f32>, lod: f32) -> vec4<f32> {
    return textureSampleLevel(t,s,uv,lod)*select(0.0,1.0,all(uv>=vec2<f32>(0.0)) && all(uv<vec2<f32>(1.0)));
}
"#);
    Ok(output)
}
fn source_hashes(dir: &Path, base: &Path, values: &mut BTreeMap<String,Value>) -> Result<()> {
    let mut paths=fs::read_dir(dir)?.map(|r|r.map(|r|r.path())).collect::<std::io::Result<Vec<_>>>()?;
    paths.sort();
    for path in paths { if path.is_dir() { source_hashes(&path,base,values)?; } else {
        let bytes=fs::read(&path)?;
        values.insert(path.strip_prefix(base)?.to_string_lossy().into(),json!({"sha256":sha(&bytes),"bytes":bytes.len()}));
    }}
    Ok(())
}

fn main() -> Result<()> {
    // Naga's SPIR-V lowering needs a generous stack, exactly as the native runtime.
    let task=std::thread::Builder::new().stack_size(16*1024*1024).spawn(export)?;
    task.join().map_err(|_|"CRT compiler panicked")?
}
fn export() -> Result<()> {
    let args=std::env::args().collect::<Vec<_>>();
    let preset=PathBuf::from(args.get(1).map(String::as_str).unwrap_or("tools/crt-export/guest1702/1702-pal.slangp"));
    let out=PathBuf::from(args.get(2).map(String::as_str).unwrap_or("web/crt"));
    fs::create_dir_all(&out)?;
    let parsed=ShaderPreset::try_parse(&preset, ShaderFeatures::NONE)?;
    let pack=ShaderPresetPack::load_from_preset::<Box<dyn Error + Send + Sync>>(parsed)?;
    let mut parameters=BTreeMap::<String,f32>::new();
    for pass in &pack.passes { for p in pass.data.parameters.values() { parameters.insert(p.id.to_string(),p.initial); }}
    for p in &pack.parameters { parameters.insert(p.name.to_string(),p.value); }
    let mut luts=Vec::new();
    for (index,lut) in pack.textures.iter().enumerate() {
        let image:Option<image::RgbaImage>=lut.data.clone().into();
        let image=image.ok_or("Invalid LUT dimensions")?;
        let asset=save(&out,&format!("lut-{index}.rgba"),image.as_raw())?;
        luts.push(json!({"index":index,"name":lut.meta.name.as_str(),"width":image.width(),"height":image.height(),
            "filter":format!("{:?}",lut.meta.filter_mode),"wrap":format!("{:?}",lut.meta.wrap_mode),"mipmap":lut.meta.mipmap,"asset":asset}));
    }
    let (artifacts,semantics)=WGSL::compile_preset_passes::<SpirvCompilation,Naga,Box<dyn Error + Send + Sync>>(
        pack.passes,pack.textures.iter().map(|t|&t.meta))?;
    let pass_filters=artifacts.iter().map(|(p,_)|format!("{:?}",p.meta.filter)=="Linear").collect::<Vec<_>>();
    let mut passes=Vec::new();
    for (index,(config,mut compiler)) in artifacts.into_iter().enumerate() {
        let reflection=compiler.reflect(index,&semantics)?;
        let compiled=compiler.compile(NagaLoweringOptions{write_pcb_as_ubo:true,sampler_bind_group:1,suppress_derivative_uniformity:true})?;
        let mut uniforms=Vec::new();
        for (name,p) in &reflection.meta.parameter_meta { uniforms.push(json!({"kind":"Parameter","name":name.as_str(),"offset":offset(p.offset),"size":p.size})); }
        for (semantic,p) in &reflection.meta.unique_meta { uniforms.push(json!({"kind":"Unique","semantic":semantic.as_str(),"offset":offset(p.offset),"size":p.size})); }
        for (semantic,p) in &reflection.meta.texture_size_meta { uniforms.push(json!({"kind":"TextureSize","texture":texture(*semantic),"offset":offset(p.offset),"size":16})); }
        uniforms.sort_by_key(Value::to_string);
        let mut textures=reflection.meta.texture_meta.iter().map(|(semantic,b)|json!({"texture":texture(*semantic),"binding":b.binding})).collect::<Vec<_>>();
        textures.sort_by_key(|t|t["binding"].as_u64());
        let ubo=reflection.ubo.as_ref().map(|u|json!({"binding":u.binding,"size":u.size,"stages":u.stage_mask.bits()}));
        let push=reflection.push_constant.as_ref().map(|u|json!({"binding":u.binding,"size":u.size,"stages":u.stage_mask.bits()}));
        let m=&config.meta;
        let format=if m.float_framebuffer { "rgba16float" } else if m.srgb_framebuffer { "rgba8unorm-srgb" } else { "rgba8unorm" };
        let vertex=save(&out,&format!("pass-{index:02}.vert.wgsl"),compiled.vertex.as_bytes())?;
        let mut border_samplers=BTreeMap::new();
        for (_,var) in compiled.context.fragment.global_variables.iter() {
            if let Some(binding)=var.binding.as_ref().filter(|b|b.group==0) {
                if let Some((semantic,_))=reflection.meta.texture_meta.iter().find(|(_,b)|b.binding==binding.binding) {
                    let linear=match semantic.semantics { TextureSemantics::Source=>pass_filters[index],TextureSemantics::Original|TextureSemantics::OriginalHistory=>pass_filters[0],TextureSemantics::PassOutput|TextureSemantics::PassFeedback=>pass_filters[semantic.index],TextureSemantics::User=>format!("{:?}",pack.textures[semantic.index].meta.filter_mode)=="Linear" };
                    border_samplers.insert(wgsl_texture_name(&compiled.fragment,binding.binding)?,linear);
                }
            }
        }
        let border_binding=reflection.meta.texture_meta.values().map(|b|b.binding)
            .chain(reflection.ubo.iter().map(|b|b.binding))
            .chain(reflection.push_constant.iter().filter_map(|b|b.binding)).max().unwrap_or(0)+1;
        let fragment_text=lower_border(&compiled.fragment,&border_samplers,border_binding)?;
        let fragment=save(&out,&format!("pass-{index:02}.frag.wgsl"),fragment_text.as_bytes())?;
        passes.push(json!({"index":index,"alias":m.alias.as_ref().map(|s|s.as_str()),"filter":format!("{:?}",m.filter),"wrap":format!("{:?}",m.wrap_mode),
            "frameCountMod":m.frame_count_mod,"mipmapInput":m.mipmap_input,"format":format,
            "scaling":{"x":scaling(&m.scaling.x),"y":scaling(&m.scaling.y)},"ubo":ubo,"push":push,"uniforms":uniforms,"textures":textures,
            "vertex":vertex,"fragment":fragment,"borderBinding":border_binding,"vertexEntry":compiled.context.vertex.entry_points[0].name,
            "fragmentEntry":compiled.context.fragment.entry_points[0].name}));
    }
    let source_dir=preset.parent().ok_or("Preset has no parent")?;
    let mut sources=BTreeMap::new(); source_hashes(source_dir,source_dir,&mut sources)?;
    for name in ["COPYING-GPL-2.0.txt","UPSTREAM.md","UPSTREAM.json","1702-pal.slangp"] { fs::copy(source_dir.join(name),out.join(name))?; }
    let manifest=json!({"version":1,"kind":"guest1702","compiler":{"librashader":"0.12.0","lowering":"same as runtime-wgpu","shaderFeatures":0},
        "preset":"1702-pal.slangp","nativeFramesPerSecond":50.0,"nativeFrameTimeDelta":20000,"passes":passes,"luts":luts,"parameters":parameters,"sourceFiles":sources});
    let manifest_bytes=serde_json::to_vec_pretty(&manifest)?;
    fs::write(out.join("guest1702.json"),&manifest_bytes)?;
    fs::write(out.join("contract.json"),serde_json::to_vec(&json!({"kind":"guest1702","version":1,"url":"./crt/guest1702.json","sha256":sha(&manifest_bytes),"bytes":manifest_bytes.len()}))?)?;
    println!("Exported {} exact Guest PAL passes and {} LUTs to {}",manifest["passes"].as_array().unwrap().len(),manifest["luts"].as_array().unwrap().len(),out.display());
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn emitted_disambiguated_names_are_adapted_by_binding() {
        // These are the actual names emitted for passes 2 and 17 by Naga 30.
        let source="@group(0) @binding(3) \nvar OriginalHistory0_: texture_2d<f32>;\n\
            @group(0) @binding(4) \nvar Pass1_: texture_2d<f32>;\n\
            fn samples() { let a=textureSample(OriginalHistory0_, s, uv); let b=textureSampleLevel(Pass1_, s, uv, 0.0); }";
        let samplers=BTreeMap::from([(wgsl_texture_name(source,3).unwrap(),false),(wgsl_texture_name(source,4).unwrap(),true)]);
        let lowered=lower_border(source,&samplers,5).unwrap();
        let body=lowered.split("@group(0) @binding(5)").next().unwrap();
        assert!(body.contains("ue2_border_nearest(OriginalHistory0_,"));
        assert!(body.contains("ue2_border_level_linear(Pass1_,"));
        assert!(!body.contains("textureSample"));
    }
    #[test]
    fn unrecognized_sampler_fails_export_instead_of_leaking_clamp_to_edge() {
        assert!(lower_border("textureSample(Unrecognized_, s, uv)",&BTreeMap::new(),5).is_err());
        assert!(lower_border("textureSampleGrad(Source, s, uv, dx, dy)",&BTreeMap::from([("Source".into(),true)]),5).is_err());
    }
}
